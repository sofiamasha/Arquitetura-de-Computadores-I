def dbin2base(base, x):
    x = x.replace(",", ".")
    
    if "." in x:
        parte_int, parte_frac = x.split(".")
    else:
        parte_int = x
        parte_frac = ""
    
    if base == 4:
        k = 2
    elif base == 8:
        k = 3
    elif base == 16:
        k = 4
    else:
        return "Base inválida"
    
    while len(parte_int) % k != 0:
        parte_int = "0" + parte_int
    
    while len(parte_frac) % k != 0:
        parte_frac = parte_frac + "0"
    
    resultado_int = ""
    for i in range(0, len(parte_int), k):
        grupo = parte_int[i:i+k]
        valor = int(grupo, 2)
        if base == 16 and valor >= 10:
            resultado_int += "ABCDEF"[valor - 10]
        else:
            resultado_int += str(valor)
    
    resultado_frac = ""
    for i in range(0, len(parte_frac), k):
        grupo = parte_frac[i:i+k]
        valor = int(grupo, 2)
        if base == 16 and valor >= 10:
            resultado_frac += "ABCDEF"[valor - 10]
        else:
            resultado_frac += str(valor)
    
    return resultado_int + "," + resultado_frac


print(dbin2base(4, "0,001011"))
print(dbin2base(8, "0,100011"))
print(dbin2base(16, "0,101100"))
print(dbin2base(8, "1,110010"))
print(dbin2base(16, "1101,1001"))