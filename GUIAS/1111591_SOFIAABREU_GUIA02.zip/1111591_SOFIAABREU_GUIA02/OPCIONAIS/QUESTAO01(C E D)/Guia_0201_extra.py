def bin2double(valor):
    if "," in valor:
        parte_inteira, parte_frac = valor.split(",")
    else:
        parte_inteira = valor
        parte_frac = ""

    decimal = 0.0

    for i in range(len(parte_inteira)):
        if parte_inteira[-(i+1)] == "1":
            decimal += 2**i

    for i in range(len(parte_frac)):
        if parte_frac[i] == "1":
            decimal += 2**(-(i+1))

    return decimal


print(bin2double("0,00011"))
print(bin2double("0,01101"))
print(bin2double("0,10001"))
print(bin2double("1,01011"))
print(bin2double("10,10101"))