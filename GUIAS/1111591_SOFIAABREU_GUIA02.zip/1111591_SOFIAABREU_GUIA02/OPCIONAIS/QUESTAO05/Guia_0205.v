module Guia_0205b;

reg [7:0] a = 8'b01010010;
reg [7:0] b = 8'b00011011;
reg [7:0] c;

initial
begin
    $display("Guia_0205b - Subtracao Binaria");
    $display("a = %8b", a);
    $display("b = %8b", b);

    c = a - b;
    $display("c = a-b = %8b", c);

    $finish;
end

endmodule