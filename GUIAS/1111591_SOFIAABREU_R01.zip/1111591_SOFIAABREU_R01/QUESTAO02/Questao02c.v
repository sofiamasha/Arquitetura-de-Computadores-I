module Questao02c(
    output s,
    input a,
    input b,
    input c
);

wire nc;
wire w1;

not NOT_1(nc,c);

or OR_1(w1,b,nc);

and AND_1(s,a,w1);

endmodule