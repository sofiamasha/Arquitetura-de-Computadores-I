module Questao02b(
    output s,
    input a,
    input b,
    input c
);

wire nc;
wire t1, t2;

not NOT_1(nc,c);

nand NAND_1(t1,a,nc);
nand NAND_2(t2,a,b);

nand NAND_3(s,t1,t2);

endmodule