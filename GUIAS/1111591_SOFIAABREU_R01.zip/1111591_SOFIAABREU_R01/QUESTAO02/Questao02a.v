module Questao02a(
    output s,
    input a,
    input b,
    input c
);

wire w1, w2;

not NOT_1(w2,c);
or OR_1(w1,w2,b);
and AND_1(s,a,w1);

endmodule