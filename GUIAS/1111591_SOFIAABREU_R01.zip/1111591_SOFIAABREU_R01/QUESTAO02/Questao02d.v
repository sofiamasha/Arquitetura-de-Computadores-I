module mux2x1(
    output s,
    input i0,
    input i1,
    input sel
);

assign s = sel ? i1 : i0;

endmodule



module Questao02d(
    output s,
    input a,
    input b,
    input c
);

wire na, nb;

wire w1, w2, w3, w4;

not NOT_1(na,a);
not NOT_2(nb,b);

mux2x1 M1(w1,0,a,b);
mux2x1 M2(w2,0,w1,c);

mux2x1 M3(w3,0,na,nb);
mux2x1 M4(w4,1,w3,c);

mux2x1 M5(s,w2,w4,c);

endmodule