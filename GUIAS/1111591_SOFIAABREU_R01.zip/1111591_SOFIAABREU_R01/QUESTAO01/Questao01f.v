module Questao01f(
    input a,
    input b,
    input c,
    input d,
    output f
);

wire nb, na, nc, nd;

assign nb = ~b;
assign na = ~a;
assign nc = ~c;
assign nd = ~d;

wire t1, t2, t3, t4;

assign t1 = ~(nb | c | d);
assign t2 = ~(a | nb | nc);
assign t3 = ~(a | nc | nd);
assign t4 = ~(b | na | nd);

assign f = ~(t1 | t2 | t3 | t4);

endmodule