module Questao01e(
    input a,
    input b,
    input c,
    input d,
    output f
);

wire nb, na, nc, nd;

assign nb = ~b;
assign na = ~a;
assign nc = ~c;
assign nd = ~d;

wire t1, t2, t3, t4;

assign t1 = ~(a & nb & d);
assign t2 = ~(na & b & c);
assign t3 = ~(na & c & d);
assign t4 = ~(b & nc & nd);

assign f = ~(t1 & t2 & t3 & t4);

endmodule