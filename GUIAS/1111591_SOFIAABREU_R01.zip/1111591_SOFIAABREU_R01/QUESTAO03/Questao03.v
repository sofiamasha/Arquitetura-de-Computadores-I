module Questao03(
    output s,
    input a,
    input b,
    input c
);

wire na, nb;

wire t1, t2, t3;

nand NAND_1(na,a,a);
nand NAND_2(nb,b,b);

nand NAND_3(t1,na,c);
nand NAND_4(t2,na,b);
nand NAND_5(t3,nb,c);

nand NAND_6(s,t1,t2,t3);

endmodule