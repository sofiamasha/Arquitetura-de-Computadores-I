module Questao04(
    output f,
    input A,
    input B,
    input C
);

wire nA, nC;

wire t1, t2, t3;

not NOT_1(nA,A);
not NOT_2(nC,C);

and AND_1(t1,nA,nC);
and AND_2(t2,B,nC);
and AND_3(t3,A,C);

or OR_1(f,t1,t2,t3);

endmodule