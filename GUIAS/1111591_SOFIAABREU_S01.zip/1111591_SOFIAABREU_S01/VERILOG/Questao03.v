module MUX (output s, input a, input b, input chave);
assign s = (chave == 0) ? a : b;
endmodule

module Questao03 (output s, input a, input b, input c);
wire w1, w2, w3, w4;

MUX m1 (w1, a, b, c);
not (w2, b);
not (w3, a);
MUX m2 (w4, w2, w3, c);
not (w2, c);
MUX m3 (s, w1, w4, w2);

endmodule

module test;
reg a, b, c;
wire s;

Questao03 uut (s, a, b, c);

initial begin
a=0; b=0; c=0;
#10 a=0; b=0; c=1;
#10 a=0; b=1; c=0;
#10 a=0; b=1; c=1;
#10 a=1; b=0; c=0;
#10 a=1; b=0; c=1;
#10 a=1; b=1; c=0;
#10 a=1; b=1; c=1;
#10 $finish;
end

endmodule