module Questao05_ts;

reg a;
reg b;
wire f;

Questao05 uut(
    .a(a),
    .b(b),
    .f(f)
);

initial begin
    a = 0; b = 0;
    #10;

    a = 0; b = 1;
    #10;

    a = 1; b = 0;
    #10;

    a = 1; b = 1;
    #10;

    $finish;
end

endmodule