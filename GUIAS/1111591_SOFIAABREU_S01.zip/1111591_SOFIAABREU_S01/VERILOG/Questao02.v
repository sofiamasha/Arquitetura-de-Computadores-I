module Questao02 (output s, input x, input y);
wire w1, w2, w3, w4, w5;

not (w1, x);
not (w2, y);
and (w3, x, w1);
or (w4, w2, y);
not (w5, w4);
and (s, w3, w5);

endmodule

module test;
reg x, y;
wire s;

Questao02 uut (s, x, y);

initial begin
x=0; y=0;
#10 x=0; y=1;
#10 x=1; y=0;
#10 x=1; y=1;
#10 $finish;
end

endmodule