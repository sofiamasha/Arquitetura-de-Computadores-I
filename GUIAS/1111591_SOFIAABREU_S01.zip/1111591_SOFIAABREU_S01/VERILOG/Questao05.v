module Questao05(
    input a,
    input b,
    output f
);

assign f = ~(a & b);

endmodule