module D_FF(
    input clk,
    input clr,
    input preset,
    input d,
    output reg q
);

always @(posedge clk or posedge clr or posedge preset)
begin
    if(clr)
        q <= 1'b0;
    else if(preset)
        q <= 1'b1;
    else
        q <= d;
end

endmodule

module Guia_1407(
    input clk,
    input clr,
    input LD,
    output [5:0] q
);

wire nq0;

assign nq0 = ~q[0];

D_FF ff0(clk,clr,LD,q[1],q[0]);
D_FF ff1(clk,clr,LD,q[2],q[1]);
D_FF ff2(clk,clr,LD,q[3],q[2]);
D_FF ff3(clk,clr,LD,q[4],q[3]);
D_FF ff4(clk,clr,LD,q[5],q[4]);
D_FF ff5(clk,clr,LD,nq0,q[5]);

endmodule