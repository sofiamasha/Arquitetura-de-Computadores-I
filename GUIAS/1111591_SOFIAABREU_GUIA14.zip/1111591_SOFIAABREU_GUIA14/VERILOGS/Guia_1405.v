module D_FF(
    input clk,
    input clr,
    input d,
    output reg q
);

always @(posedge clk or posedge clr)
begin
    if(clr)
        q <= 1'b0;
    else
        q <= d;
end

endmodule

module Guia_1405(
    input clk,
    input clr,
    input load,
    input p4,
    input p3,
    input p2,
    input p1,
    input p0,
    output serial
);

wire q0;
wire q1;
wire q2;
wire q3;
wire q4;

wire d0;
wire d1;
wire d2;
wire d3;
wire d4;

assign d0 = load ? p0 : q1;
assign d1 = load ? p1 : q2;
assign d2 = load ? p2 : q3;
assign d3 = load ? p3 : q4;
assign d4 = load ? p4 : 1'b0;

D_FF ff0(clk,clr,d0,q0);
D_FF ff1(clk,clr,d1,q1);
D_FF ff2(clk,clr,d2,q2);
D_FF ff3(clk,clr,d3,q3);
D_FF ff4(clk,clr,d4,q4);

assign serial = q0;

endmodule