module tb;

reg clk;
reg clr;
reg LD;

wire [4:0] q;

Guia_1401 dut(
    .clk(clk),
    .clr(clr),
    .LD(LD),
    .q(q)
);

initial
begin
    clk = 0;
    clr = 1;
    LD = 0;

    #10 clr = 0;
    #10 LD = 1;
    #10 LD = 0;

    #100 $finish;
end

always #5 clk = ~clk;

initial
begin
    $monitor("t=%0d LD=%b q=%b",$time,LD,q);
end

endmodule