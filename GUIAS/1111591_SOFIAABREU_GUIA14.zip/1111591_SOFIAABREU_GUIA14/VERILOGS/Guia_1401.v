module D_FF(
    input clk,
    input clr,
    input preset,
    input d,
    output reg q
);

always @(posedge clk or posedge clr or posedge preset)
begin
    if (clr)
        q <= 1'b0;
    else if (preset)
        q <= 1'b1;
    else
        q <= d;
end

endmodule

module Guia_1401(
    input clk,
    input clr,
    input LD,
    output [4:0] q
);

wire q0;
wire q1;
wire q2;
wire q3;
wire q4;

D_FF ff0(
    .clk(clk),
    .clr(clr),
    .preset(LD),
    .d(1'b0),
    .q(q0)
);

D_FF ff1(
    .clk(clk),
    .clr(clr),
    .preset(1'b0),
    .d(q0),
    .q(q1)
);

D_FF ff2(
    .clk(clk),
    .clr(clr),
    .preset(1'b0),
    .d(q1),
    .q(q2)
);

D_FF ff3(
    .clk(clk),
    .clr(clr),
    .preset(1'b0),
    .d(q2),
    .q(q3)
);

D_FF ff4(
    .clk(clk),
    .clr(clr),
    .preset(1'b0),
    .d(q3),
    .q(q4)
);

assign q[0] = q0;
assign q[1] = q1;
assign q[2] = q2;
assign q[3] = q3;
assign q[4] = q4;

endmodule