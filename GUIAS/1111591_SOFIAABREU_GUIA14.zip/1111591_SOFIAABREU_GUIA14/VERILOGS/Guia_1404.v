module D_FF(
    input clk,
    input clr,
    input preset,
    input d,
    output reg q
);

always @(posedge clk or posedge clr or posedge preset)
begin
    if (clr)
        q <= 1'b0;
    else if (preset)
        q <= 1'b1;
    else
        q <= d;
end

endmodule

module Guia_1404(
    input clk,
    input clr,
    input LD,
    output [4:0] q
);

wire nq4;

assign nq4 = ~q[4];

D_FF ff0(
    .clk(clk),
    .clr(clr),
    .preset(LD),
    .d(nq4),
    .q(q[0])
);

D_FF ff1(
    .clk(clk),
    .clr(clr),
    .preset(1'b0),
    .d(q[0]),
    .q(q[1])
);

D_FF ff2(
    .clk(clk),
    .clr(clr),
    .preset(1'b0),
    .d(q[1]),
    .q(q[2])
);

D_FF ff3(
    .clk(clk),
    .clr(clr),
    .preset(1'b0),
    .d(q[2]),
    .q(q[3])
);

D_FF ff4(
    .clk(clk),
    .clr(clr),
    .preset(1'b0),
    .d(q[3]),
    .q(q[4])
);

endmodule