module Guia_0501 (output s, input a, input b);

wire na;
wire nb;
wire t;

nand (na, a, a);
nand (nb, b, b);
nand (t, na, nb);
nand (s, t, t);

endmodule


module teste;

reg a;
reg b;
wire s;

Guia_0501 uut (s,a,b);

initial
begin

$display("a b | s");

a=0; b=0; #10
$display("%b %b | %b",a,b,s);

a=0; b=1; #10
$display("%b %b | %b",a,b,s);

a=1; b=0; #10
$display("%b %b | %b",a,b,s);

a=1; b=1; #10
$display("%b %b | %b",a,b,s);

end

endmodule
