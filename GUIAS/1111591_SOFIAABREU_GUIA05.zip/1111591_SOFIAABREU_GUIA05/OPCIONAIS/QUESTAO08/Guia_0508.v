module Guia_0508 (output s, input a, input b);

wire t1;
wire t2;

// inverter a
nor (t1, a, a);

// ~(~a | b)
nor (t2, t1, b);

// inverter resultado
nor (s, t2, t2);

endmodule

//TESTE

module test_Guia_0508;

reg a;
reg b;
wire s;

Guia_0508 uut (s, a, b);

initial
begin

$display("a b | s");

a=0; b=0; #1 $display("%b %b | %b",a,b,s);
a=0; b=1; #1 $display("%b %b | %b",a,b,s);
a=1; b=0; #1 $display("%b %b | %b",a,b,s);
a=1; b=1; #1 $display("%b %b | %b",a,b,s);

end

endmodule
