module Guia_0507 (output s, input a, input b);

wire t1;
wire t2;
wire t3;

nand (t1, a, b);
nand (t2, a, t1);
nand (t3, b, t1);
nand (s, t2, t3);

endmodule


module teste;

reg a;
reg b;
wire s;

Guia_0507 uut (s,a,b);

initial
begin

$display("Tabela verdade ~(a ^ ~b)");
$display("a b | s");

a=0; b=0; #10
$display("%b %b | %b",a,b,s);

a=0; b=1; #10
$display("%b %b | %b",a,b,s);

a=1; b=0; #10
$display("%b %b | %b",a,b,s);

a=1; b=1; #10
$display("%b %b | %b",a,b,s);

end

endmodule
