module Guia_0506 (output s, input a, input b);

wire t1;
wire t2;
wire t3;
wire t4;

nor (t1, a, b);
nor (t2, a, t1);
nor (t3, b, t1);
nor (t4, t2, t3);
nor (s, t4, t4);

endmodule


module teste;

reg a;
reg b;
wire s;

Guia_0506 uut (s,a,b);

initial
begin

$display("Tabela verdade XOR (a ^ b)");
$display("a b | s");

a=0; b=0; #10
$display("%b %b | %b",a,b,s);

a=0; b=1; #10
$display("%b %b | %b",a,b,s);

a=1; b=0; #10
$display("%b %b | %b",a,b,s);

a=1; b=1; #10
$display("%b %b | %b",a,b,s);

end

endmodule
