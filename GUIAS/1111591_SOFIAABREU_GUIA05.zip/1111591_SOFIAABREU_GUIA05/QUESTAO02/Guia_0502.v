module Guia_0502 (output s, input a, input b);

wire na;
wire nb;
wire t;

nor (na, a, a);     // ~a
nor (nb, b, b);     // ~b
nor (t, na, nb);    // ~(~a | ~b)
nor (s, t, t);      // (~a | ~b)

endmodule


module teste;

reg a;
reg b;
wire s;

Guia_0502 uut (s,a,b);

initial
begin

$display("Tabela verdade (~a | ~b)");
$display("a b | s");

a=0; b=0; #10
$display("%b %b | %b",a,b,s);

a=0; b=1; #10
$display("%b %b | %b",a,b,s);

a=1; b=0; #10
$display("%b %b | %b",a,b,s);

a=1; b=1; #10
$display("%b %b | %b",a,b,s);

end

endmodule
