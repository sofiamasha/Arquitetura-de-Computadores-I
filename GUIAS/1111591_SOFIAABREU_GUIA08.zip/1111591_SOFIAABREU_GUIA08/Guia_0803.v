module bitEqual(output s, input a, input b);
xnor (s, a, b);
endmodule

module LU_6bits_equal(output s, input [5:0] x, input [5:0] y);
wire s0, s1, s2, s3, s4, s5;

bitEqual B0(s0, x[0], y[0]);
bitEqual B1(s1, x[1], y[1]);
bitEqual B2(s2, x[2], y[2]);
bitEqual B3(s3, x[3], y[3]);
bitEqual B4(s4, x[4], y[4]);
bitEqual B5(s5, x[5], y[5]);

and (s, s0, s1, s2, s3, s4, s5);
endmodule

module test_LU_6bits_equal;
reg [5:0] x;
reg [5:0] y;
wire s;

LU_6bits_equal DUT(s, x, y);

initial begin
x = 6'b000001; y = 6'b000001;
#10;
x = 6'b101010; y = 6'b101010;
#10;
x = 6'b111000; y = 6'b111001;
#10;
x = 6'b000111; y = 6'b111000;
end
endmodule
