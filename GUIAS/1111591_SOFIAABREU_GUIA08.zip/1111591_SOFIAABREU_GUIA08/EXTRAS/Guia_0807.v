module comparador_eq(output s, input [4:0] x, input [4:0] y);
wire [4:0] t;

xnor (t[0], x[0], y[0]);
xnor (t[1], x[1], y[1]);
xnor (t[2], x[2], y[2]);
xnor (t[3], x[3], y[3]);
xnor (t[4], x[4], y[4]);

and (s, t[0], t[1], t[2], t[3], t[4]);
endmodule

module comparador_diff(output s, input [4:0] x, input [4:0] y);
wire [4:0] t;

xor (t[0], x[0], y[0]);
xor (t[1], x[1], y[1]);
xor (t[2], x[2], y[2]);
xor (t[3], x[3], y[3]);
xor (t[4], x[4], y[4]);

or (s, t[0], t[1], t[2], t[3], t[4]);
endmodule

module LU_5bits_comp(
output s,
input [4:0] x,
input [4:0] y,
input sel
);
wire eq, diff;
wire nsel, r1, r2;

comparador_eq CE(eq, x, y);
comparador_diff CD(diff, x, y);

not (nsel, sel);
and (r1, eq, nsel);
and (r2, diff, sel);
or (s, r1, r2);
endmodule

module test_LU_5bits_comp;
reg [4:0] x;
reg [4:0] y;
reg sel;
wire s;

LU_5bits_comp DUT(s, x, y, sel);

initial begin
x = 5'b00101; y = 5'b00101; sel = 0;
#10;
x = 5'b00101; y = 5'b00101; sel = 1;
#10;
x = 5'b01010; y = 5'b01110; sel = 0;
#10;
x = 5'b01010; y = 5'b01110; sel = 1;
end
endmodule
