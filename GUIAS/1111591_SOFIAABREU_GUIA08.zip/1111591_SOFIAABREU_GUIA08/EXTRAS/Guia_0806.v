module halfAdder(output c, output s, input a, input b);
xor (s, a, b);
and (c, a, b);
endmodule

module fullAdder(output cOut, output s, input a, input b, input cIn);
wire s1, c1, c2;
halfAdder HA1(c1, s1, a, b);
halfAdder HA2(c2, s, s1, cIn);
or (cOut, c1, c2);
endmodule

module invCond(output y, input x, input sel);
xor (y, x, sel);
endmodule

module comparador_eq(output s, input [4:0] x, input [4:0] y);
wire [4:0] t;
xnor (t[0], x[0], y[0]);
xnor (t[1], x[1], y[1]);
xnor (t[2], x[2], y[2]);
xnor (t[3], x[3], y[3]);
xnor (t[4], x[4], y[4]);
and (s, t[0], t[1], t[2], t[3], t[4]);
endmodule

module comparador_diff(output s, input [4:0] x, input [4:0] y);
wire [4:0] t;
xor (t[0], x[0], y[0]);
xor (t[1], x[1], y[1]);
xor (t[2], x[2], y[2]);
xor (t[3], x[3], y[3]);
xor (t[4], x[4], y[4]);
or (s, t[0], t[1], t[2], t[3], t[4]);
endmodule

module AU_5bits(
output [4:0] s,
output carryOut,
output result,
input [4:0] x,
input [4:0] y,
input carryIn,
input sel
);
wire [4:0] yInv;
wire [4:0] carry;
wire eq, diff;

invCond I0(yInv[0], y[0], carryIn);
invCond I1(yInv[1], y[1], carryIn);
invCond I2(yInv[2], y[2], carryIn);
invCond I3(yInv[3], y[3], carryIn);
invCond I4(yInv[4], y[4], carryIn);

fullAdder FA0(carry[0], s[0], x[0], yInv[0], carryIn);
fullAdder FA1(carry[1], s[1], x[1], yInv[1], carry[0]);
fullAdder FA2(carry[2], s[2], x[2], yInv[2], carry[1]);
fullAdder FA3(carry[3], s[3], x[3], yInv[3], carry[2]);
fullAdder FA4(carry[4], s[4], x[4], yInv[4], carry[3]);

assign carryOut = carry[4];

comparador_eq CE(eq, x, y);
comparador_diff CD(diff, x, y);

wire nsel, r1, r2;
not (nsel, sel);
and (r1, eq, nsel);
and (r2, diff, sel);
or (result, r1, r2);
endmodule

module test_AU_5bits;
reg [4:0] x;
reg [4:0] y;
reg carryIn;
reg sel;
wire [4:0] s;
wire carryOut;
wire result;

AU_5bits DUT(s, carryOut, result, x, y, carryIn, sel);

initial begin
x = 5'b00101; y = 5'b00011; carryIn = 0; sel = 0;
#10;
x = 5'b00101; y = 5'b00011; carryIn = 1; sel = 1;
#10;
x = 5'b01010; y = 5'b01010; carryIn = 0; sel = 0;
#10;
x = 5'b01010; y = 5'b01110; carryIn = 0; sel = 1;
end
endmodule
