module halfSubtractor(output b1, output d, input a, input b);
xor (d, a, b);
not (nb, a);
and (b1, nb, b);
endmodule

module fullSubtractor(output bOut, output d, input a, input b, input bIn);
wire d1, b1, b2;

halfSubtractor HS1(b1, d1, a, b);
halfSubtractor HS2(b2, d, d1, bIn);
or (bOut, b1, b2);
endmodule

module AU_6bits_sub;
reg [5:0] x;
reg [5:0] y;
wire [5:0] d;
wire [5:0] borrow;
wire borrowFinal;

fullSubtractor FS0(borrow[0], d[0], x[0], y[0], 1'b0);
fullSubtractor FS1(borrow[1], d[1], x[1], y[1], borrow[0]);
fullSubtractor FS2(borrow[2], d[2], x[2], y[2], borrow[1]);
fullSubtractor FS3(borrow[3], d[3], x[3], y[3], borrow[2]);
fullSubtractor FS4(borrow[4], d[4], x[4], y[4], borrow[3]);
fullSubtractor FS5(borrow[5], d[5], x[5], y[5], borrow[4]);

assign borrowFinal = borrow[5];

initial begin
x = 6'b000101; y = 6'b000001;
#10;
x = 6'b001000; y = 6'b000011;
#10;
x = 6'b000001; y = 6'b000010;
end
endmodule
