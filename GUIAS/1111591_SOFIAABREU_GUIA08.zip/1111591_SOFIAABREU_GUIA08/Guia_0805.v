module comp1_6bits(output [5:0] y, input [5:0] x);
not (y[0], x[0]);
not (y[1], x[1]);
not (y[2], x[2]);
not (y[3], x[3]);
not (y[4], x[4]);
not (y[5], x[5]);
endmodule

module halfAdder(output c, output s, input a, input b);
xor (s, a, b);
and (c, a, b);
endmodule

module fullAdder(output cOut, output s, input a, input b, input cIn);
wire s1, c1, c2;

halfAdder HA1(c1, s1, a, b);
halfAdder HA2(c2, s, s1, cIn);
or (cOut, c1, c2);
endmodule

module comp2_6bits(output [5:0] y, input [5:0] x);
wire [5:0] c1;
wire [5:0] carry;

comp1_6bits C1(c1, x);

fullAdder FA0(carry[0], y[0], c1[0], 1'b1, 1'b0);
fullAdder FA1(carry[1], y[1], c1[1], 1'b0, carry[0]);
fullAdder FA2(carry[2], y[2], c1[2], 1'b0, carry[1]);
fullAdder FA3(carry[3], y[3], c1[3], 1'b0, carry[2]);
fullAdder FA4(carry[4], y[4], c1[4], 1'b0, carry[3]);
fullAdder FA5(carry[5], y[5], c1[5], 1'b0, carry[4]);
endmodule

module test_comp2_6bits;
reg [5:0] x;
wire [5:0] y;

comp2_6bits DUT(y, x);

initial begin
x = 6'b000001;
#10;
x = 6'b000010;
#10;
x = 6'b001011;
#10;
x = 6'b111111;
end
endmodule
