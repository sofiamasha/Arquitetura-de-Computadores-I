Guia 08 – Arquitetura de Computadores I

Este trabalho apresenta a implementação de unidades aritméticas e lógicas em Verilog, utilizando portas nativas, conforme proposto nas atividades do Guia 08.

Durante o desenvolvimento, foram implementados módulos como somadores, subtratores, comparadores de igualdade e desigualdade, além de operações como complemento de 2, seguindo a lógica de construção modular e reutilização de componentes.

Entretanto, é importante destacar que o desenvolvimento desta atividade foi impactado por limitações pessoais ao longo da semana, especialmente devido a episódios frequentes de enxaqueca, o que acabou afetando o ritmo de estudo e a profundidade de alguns testes e refinamentos.

Mesmo assim, todos os principais conceitos foram aplicados e os módulos funcionais foram implementados conforme solicitado, buscando manter a organização, clareza e coerência com o conteúdo apresentado em aula.

Este trabalho representa, portanto, o esforço de consolidar os conceitos fundamentais da disciplina dentro das condições disponíveis no período.
