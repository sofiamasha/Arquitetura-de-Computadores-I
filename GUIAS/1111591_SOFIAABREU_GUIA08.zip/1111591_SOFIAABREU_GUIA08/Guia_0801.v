module halfAdder (output s1, output s0, input a, input b);
    xor (s0, a, b);
    and (s1, a, b);
endmodule

module fullAdder (output s1, output s0, input a, input b, input carryIn);
    wire s_parcial, carry1, carry2;

    halfAdder HA1 (carry1, s_parcial, a, b);
    halfAdder HA2 (carry2, s0, s_parcial, carryIn);
    or (s1, carry1, carry2);
endmodule

module AU_6bits (output [5:0] soma, output carryOut, input [5:0] x, input [5:0] y);
    wire [5:0] carry;

    fullAdder FA0 (carry[0], soma[0], x[0], y[0], 1'b0);
    fullAdder FA1 (carry[1], soma[1], x[1], y[1], carry[0]);
    fullAdder FA2 (carry[2], soma[2], x[2], y[2], carry[1]);
    fullAdder FA3 (carry[3], soma[3], x[3], y[3], carry[2]);
    fullAdder FA4 (carry[4], soma[4], x[4], y[4], carry[3]);
    fullAdder FA5 (carry[5], soma[5], x[5], y[5], carry[4]);

    assign carryOut = carry[5];
endmodule

module test_AU_6bits;

    reg [5:0] x;
    reg [5:0] y;
    wire [5:0] soma;
    wire carryOut;

    AU_6bits AU (soma, carryOut, x, y);

    initial begin
        $display("Guia_0801 - Sofia de Abreu");

        x = 6'b000000; y = 6'b000000;
        #1 $display("%b + %b = %b carry=%b", x, y, soma, carryOut);

        x = 6'b000001; y = 6'b000001;
        #1 $display("%b + %b = %b carry=%b", x, y, soma, carryOut);

        x = 6'b001010; y = 6'b000101;
        #1 $display("%b + %b = %b carry=%b", x, y, soma, carryOut);

        x = 6'b011111; y = 6'b000001;
        #1 $display("%b + %b = %b carry=%b", x, y, soma, carryOut);

        x = 6'b111111; y = 6'b000001;
        #1 $display("%b + %b = %b carry=%b", x, y, soma, carryOut);
    end

endmodule