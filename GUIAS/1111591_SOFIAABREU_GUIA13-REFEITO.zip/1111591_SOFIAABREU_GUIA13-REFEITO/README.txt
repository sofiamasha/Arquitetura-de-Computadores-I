Tabela verdade do Flip Flop JK

J   K   Q   Q'
-----------------
0   0   Q   Q' -> Hold
0   1   0   1 ->  Reset
1   0   1   0 ->  Set
1   1   Q'  Q ->  Toggle



tabela de estados

 #  a  b  c  a  b 
------------------------- 
 0 | 0  0  0  0  0 
 1 | 0  0  1  1  1 
 2 | 0  1  0  0  1 
 3 | 0  1  1  0  0 
 4 | 1  0  0  1  0 
 5 | 1  0  1  0  1 
 6 | 1  1  0  1  1 
 7 | 1  1  1  1  0 


Sops

s1 =  (1,4,6,7)

S1​(a,b,c) = a'b'c+ab'c'+abc'+abc

s2 = (1,2,5,6)

S2​ = a'b'c+a'bc'+ab'c+abc'



Flip Flop T
T	Q	Q'
-----------
0	Q	Q
1	Q	Q'

Flip Flop T - Tabela de Estados
 # | a  b  c  a  b 
--------------------
 0 | 0  0  0  0  0 
 1 | 0  0  1  1  1 
 2 | 0  1  0  0  1 
 3 | 0  1  1  0  0 
 4 | 1  0  0  1  0 
 5 | 1  0  1  0  1 
 6 | 1  1  0  1  1 
 7 | 1  1  1  1  0 




