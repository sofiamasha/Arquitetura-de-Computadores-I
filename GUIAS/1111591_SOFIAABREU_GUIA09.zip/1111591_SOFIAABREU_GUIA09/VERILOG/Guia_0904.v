`include "clock.v"

module pulse ( signal, clock );
input clock;
output signal;
reg signal;

initial
begin
 signal = 1'b0;
end

always @ ( posedge clock or negedge clock )
begin
 signal = ~signal;
end
endmodule

module Guia_0904;
wire clock;
clock clk ( clock );

wire p;

pulse pls ( p, clock );

initial
begin
 $dumpfile("Guia_0904.vcd");
 $dumpvars(1, clock, p);
 #480 $finish;
end
endmodule