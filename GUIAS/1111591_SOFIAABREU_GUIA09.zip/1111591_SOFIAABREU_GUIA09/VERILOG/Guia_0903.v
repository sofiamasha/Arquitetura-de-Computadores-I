`include "clock.v"

module pulse ( signal, clock );
input clock;
output signal;
reg signal;

integer count;

initial
begin
 signal = 1'b0;
 count = 0;
end

always @ ( posedge clock )
begin
 count = count + 1;

 if ( count == 3 )
 begin
  signal = ~signal;
  count = 0;
 end
end
endmodule

module Guia_0903;
wire clock;
clock clk ( clock );

wire p;

pulse pls ( p, clock );

initial
begin
 $dumpfile("Guia_0903.vcd");
 $dumpvars(1, clock, p);
 #480 $finish;
end
endmodule