`include "clock.v"

module pulse ( signal, clock );
input clock;
output signal;
reg signal;

always @ ( clock )
begin
 if ( clock == 1'b1 )
 begin
  signal = 1'b1;
  #4 signal = 1'b0;
 end
end
endmodule

module Guia_0907;
wire clock;
clock clk ( clock );

wire p;

pulse pls ( p, clock );

initial
begin
 $dumpfile("Guia_0907.vcd");
 $dumpvars(1, clock, p);
 #480 $finish;
end
endmodule