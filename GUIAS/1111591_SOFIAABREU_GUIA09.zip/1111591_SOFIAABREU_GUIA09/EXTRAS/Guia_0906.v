`include "clock.v"

module pulse ( signal, clock );
input clock;
output signal;
reg signal;

always @ ( negedge clock )
begin
 signal = 1'b1;
 #2 signal = 1'b0;
end
endmodule

module Guia_0906;
wire clock;
clock clk ( clock );

wire p;

pulse pls ( p, clock );

initial
begin
 $dumpfile("Guia_0906.vcd");
 $dumpvars(1, clock, p);
 #480 $finish;
end
endmodule