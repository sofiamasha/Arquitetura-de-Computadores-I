module Guia_0706 (
    input a0, input a1, input a2, input a3,
    input b0, input b1, input b2, input b3,
    input sel,
    output out
);

wire xnor0, xnor1, xnor2, xnor3;
wire xor0, xor1, xor2, xor3;

wire igual;
wire diferente;

wire not_sel;

xnor (xnor0, a0, b0);
xnor (xnor1, a1, b1);
xnor (xnor2, a2, b2);
xnor (xnor3, a3, b3);

xor (xor0, a0, b0);
xor (xor1, a1, b1);
xor (xor2, a2, b2);
xor (xor3, a3, b3);

and (igual, xnor0, xnor1, xnor2, xnor3);

or (diferente, xor0, xor1, xor2, xor3);

not (not_sel, sel);

wire eq_sel;
wire dif_sel;

and (eq_sel, igual, not_sel);
and (dif_sel, diferente, sel);

or (out, eq_sel, dif_sel);

endmodule