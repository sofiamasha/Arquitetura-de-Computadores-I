module Guia_0707 (
    input a3,a2,a1,a0,
    input b3,b2,b1,b0,
    input sel,
    output out
);

wire na3,na2,na1,na0;
wire nb3,nb2,nb1,nb0;

not (na3,a3); not (na2,a2); not (na1,a1); not (na0,a0);
not (nb3,b3); not (nb2,b2); not (nb1,b1); not (nb0,b0);

wire eq3,eq2,eq1,eq0;

wire t1,t2,t3,t4,t5,t6,t7,t8;

and (t1,a3,b3);
and (t2,na3,nb3);
or (eq3,t1,t2);

and (t3,a2,b2);
and (t4,na2,nb2);
or (eq2,t3,t4);

and (t5,a1,b1);
and (t6,na1,nb1);
or (eq1,t5,t6);

and (t7,a0,b0);
and (t8,na0,nb0);
or (eq0,t7,t8);

wire m3,m2,m1,m0;
wire n3,n2,n1,n0;

and (m3,a3,nb3);
and (m2,a2,nb2);
and (m1,a1,nb1);
and (m0,a0,nb0);

and (n3,na3,b3);
and (n2,na2,b2);
and (n1,na1,b1);
and (n0,na0,b0);

wire maior,menor;

wire c1,c2,c3,c4,c5,c6;

and (c1,eq3,m2);
and (c2,eq3,eq2,m1);
and (c3,eq3,eq2,eq1,m0);

or (maior,m3,c1,c2,c3);

and (c4,eq3,n2);
and (c5,eq3,eq2,n1);
and (c6,eq3,eq2,eq1,n0);

or (menor,n3,c4,c5,c6);

wire not_sel;
wire s1,s2;

not (not_sel,sel);

and (s1,maior,not_sel);
and (s2,menor,sel);

or (out,s1,s2);

endmodule