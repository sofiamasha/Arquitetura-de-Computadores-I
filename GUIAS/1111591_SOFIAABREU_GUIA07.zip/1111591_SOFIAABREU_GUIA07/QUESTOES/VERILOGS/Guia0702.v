module Guia_0702 (
    input a,
    input b,
    input sel,
    output out
);

wire or_out;
wire nor_out;
wire not_sel;
wire or_sel;
wire nor_sel;

or (or_out, a, b);

nor (nor_out, a, b);

not (not_sel, sel);

and (or_sel, or_out, not_sel);   // sel = 0 → OR
and (nor_sel, nor_out, sel);     // sel = 1 → NOR

or (out, or_sel, nor_sel);

endmodule