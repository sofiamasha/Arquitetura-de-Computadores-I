module Guia_0704 (
    input a,
    input b,
    input s0,
    input s1,
    output out
);

wire xor_out;
wire xnor_out;
wire or_out;
wire nor_out;

wire not_s0;
wire not_s1;

wire sel0;
wire sel1;
wire sel2;
wire sel3;

xor (xor_out, a, b);
xnor (xnor_out, a, b);
or (or_out, a, b);
nor (nor_out, a, b);

not (not_s0, s0);
not (not_s1, s1);

and (sel0, xor_out, not_s1, not_s0);
and (sel1, xnor_out, not_s1, s0);
and (sel2, nor_out, s1, not_s0);
and (sel3, or_out, s1, s0);

or (out, sel0, sel1, sel2, sel3);

endmodule