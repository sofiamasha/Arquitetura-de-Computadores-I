module test_0702;

reg a, b, sel;
wire out;

Guia_0702 uut (a, b, sel, out);

initial begin

    $display("a b sel | out");

    a=0; b=0; sel=0; #1;
    $display("%b %b %b | %b", a,b,sel,out);

    a=0; b=1; sel=0; #1;
    $display("%b %b %b | %b", a,b,sel,out);

    a=1; b=0; sel=1; #1;
    $display("%b %b %b | %b", a,b,sel,out);

    a=1; b=1; sel=1; #1;
    $display("%b %b %b | %b", a,b,sel,out);

end

endmodule