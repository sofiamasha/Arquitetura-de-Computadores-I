module Guia_0701 (
    input a,
    input b,
    input sel,
    output and_out,
    output nand_out,
    output out
);

wire not_sel;
wire and_sel;
wire nand_sel;

and (and_out, a, b);

nand (nand_out, a, b);

not (not_sel, sel);

and (and_sel, and_out, not_sel);
and (nand_sel, nand_out, sel);

or (out, and_sel, nand_sel);

endmodule