module Guia_0703 (
    input a,
    input b,
    input sel_op,
    input sel_grp,
    output out
);

wire and_out;
wire nand_out;
wire or_out;
wire nor_out;

wire not_sel_op;
wire not_sel_grp;

wire and_sel;
wire nand_sel;
wire or_sel;
wire nor_sel;

wire group_and;
wire group_or;

and (and_out, a, b);
nand (nand_out, a, b);
or (or_out, a, b);
nor (nor_out, a, b);

not (not_sel_op, sel_op);
not (not_sel_grp, sel_grp);

and (and_sel, and_out, not_sel_op);
and (nand_sel, nand_out, sel_op);
or (group_and, and_sel, nand_sel);

and (or_sel, or_out, not_sel_op);
and (nor_sel, nor_out, sel_op);
or (group_or, or_sel, nor_sel);

and (group_and, group_and, sel_grp);
and (group_or, group_or, not_sel_grp);

or (out, group_and, group_or);

endmodule