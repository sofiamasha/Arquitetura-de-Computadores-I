module test_0704;

reg a, b, s0, s1;
wire out;

Guia_0704 uut (a, b, s0, s1, out);

initial begin

a=0; b=0; s1=0; s0=0; #1;
a=0; b=1; s1=0; s0=1; #1;
a=1; b=0; s1=1; s0=0; #1;
a=1; b=1; s1=1; s0=1; #1;

end

endmodule