module test_0703;

reg a, b, sel_op, sel_grp;
wire out;

Guia_0703 uut (a, b, sel_op, sel_grp, out);

initial begin

a=0; b=0; sel_op=0; sel_grp=0; #1;
a=0; b=1; sel_op=0; sel_grp=0; #1;
a=1; b=1; sel_op=1; sel_grp=0; #1;

a=0; b=0; sel_op=0; sel_grp=1; #1;
a=0; b=1; sel_op=1; sel_grp=1; #1;
a=1; b=1; sel_op=1; sel_grp=1; #1;

end

endmodule