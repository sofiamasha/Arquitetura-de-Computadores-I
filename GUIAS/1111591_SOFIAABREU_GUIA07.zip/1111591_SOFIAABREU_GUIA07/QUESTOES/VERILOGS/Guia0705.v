module Guia_0705 (
    input a,
    input b,
    input s0,
    input s1,
    input s2,
    input neg,
    output out
);

wire a_neg;

wire not_out;
wire and_out;
wire nand_out;
wire or_out;
wire nor_out;
wire xor_out;
wire xnor_out;

wire not_s0;
wire not_s1;
wire not_s2;

wire sel0;
wire sel1;
wire sel2;
wire sel3;
wire sel4;
wire sel5;
wire sel6;

not (a_neg, a);

and (not_out, a_neg, neg);
and (and_out, a, b);
nand (nand_out, a, b);
or (or_out, a, b);
nor (nor_out, a, b);
xor (xor_out, a, b);
xnor (xnor_out, a, b);

not (not_s0, s0);
not (not_s1, s1);
not (not_s2, s2);

and (sel0, not_out, not_s2, not_s1, not_s0);
and (sel1, and_out, not_s2, not_s1, s0);
and (sel2, nand_out, not_s2, s1, not_s0);
and (sel3, or_out, not_s2, s1, s0);
and (sel4, nor_out, s2, not_s1, not_s0);
and (sel5, xor_out, s2, not_s1, s0);
and (sel6, xnor_out, s2, s1, not_s0);

or (out, sel0, sel1, sel2, sel3, sel4, sel5, sel6);

endmodule