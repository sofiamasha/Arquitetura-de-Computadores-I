module test;

reg a, b, sel;
wire and_out, nand_out, out;

Guia_0701 uut (a, b, sel, and_out, nand_out, out);

initial begin

    a=0; b=0; sel=0; #1;
    a=0; b=1; sel=0; #1;
    a=1; b=0; sel=1; #1;
    a=1; b=1; sel=1; #1;

end

endmodule