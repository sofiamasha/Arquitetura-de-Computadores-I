module test_0705;

reg a, b, s0, s1, s2, neg;
wire out;

Guia_0705 uut (a, b, s0, s1, s2, neg, out);

initial begin

a=0; b=0; s2=0; s1=0; s0=0; neg=1; #1;
a=1; b=1; s2=0; s1=0; s0=1; neg=0; #1;
a=1; b=0; s2=0; s1=1; s0=0; neg=0; #1;
a=1; b=1; s2=0; s1=1; s0=1; neg=0; #1;
a=0; b=0; s2=1; s1=0; s0=0; neg=0; #1;
a=1; b=0; s2=1; s1=0; s0=1; neg=0; #1;
a=1; b=1; s2=1; s1=1; s0=0; neg=0; #1;

end

endmodule