Olá, Theldo, bom dia! Tudo bem?

Queria comentar sobre uma das questões do Logisim (acredito que seja a 4). Eu tentei montar o circuito, mas tive dificuldade em uma das portas, e por isso não consegui finalizar corretamente.

Revisei o que fiz e tentei ajustar, mas ainda assim não consegui chegar ao resultado esperado. De qualquer forma, procurei desenvolver a lógica e montar o circuito da melhor forma que consegui.

Se puder dar uma olhada ou me orientar sobre onde posso ter errado, agradeço bastante, pois quero entender melhor para melhorar.

Obrigada pela atenção!
