def baseEval(x, op, y, base):
    a = int(x, base)
    b = int(y, base)

    if op == "-":
        r = a - b
    elif op == "+":
        r = a + b
    elif op == "*":
        r = a * b
    elif op == "/":
        r = a // b

    if base == 2:
        return format(r, 'b')
    if base == 4:
        return format(r, 'b')
    if base == 8:
        return format(r, 'o')
    if base == 16:
        return format(r, 'X')

print("a)", baseEval("11011","-","1101",2))
print("b)", baseEval("101.1001".replace(".",""),"-","10.11".replace(".",""),2))
print("c)", baseEval("312","-","123",4))
print("d)", baseEval("754","-","367",8))
print("e)", baseEval("A85","-","C14",16))