/*
 Guia_0302.v
 1111591 - Sofia
*/

module Guia_0302;

reg [7:0] a = 8'hD6;
reg [9:0] b = 10'o157;
reg [7:0] c = 8'h8E;

reg [7:0] d = 0;
reg [9:0] e = 0;
reg [7:0] f = 0;

initial
begin : main

$display("Guia_0302 - Tests");

d = ~a + 1;
$display("a = %8b -> C1(a) = %8b -> C2(a) = %8b", a, ~a, d);

e = ~b + 1;
$display("b = %10b -> C1(b) = %10b -> C2(b) = %10b", b, ~b, e);

f = ~c + 1;
$display("c = %8b -> C1(c) = %8b -> C2(c) = %8b", c, ~c, f);

end

endmodule