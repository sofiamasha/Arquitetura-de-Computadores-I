/*
 Guia_0301.v
 1111591 - Sofia
*/

module Guia_0301;

reg [7:0] a = 8'b00001010;
reg [7:0] b = 8'b00001001;
reg [5:0] c = 6'b101001;
reg [6:0] d = 7'b0101011;
reg [7:0] e = 8'b00111010;

reg [7:0] r1 = 0;
reg [7:0] r2 = 0;
reg [5:0] r3 = 0;
reg [6:0] r4 = 0;
reg [7:0] r5 = 0;

initial
begin : main

$display("Guia_0301 - Testes");

r1 = ~a + 1;
$display("a = %8b -> C1 = %8b -> C2 = %8b", a, ~a, r1);

r2 = ~b + 1;
$display("b = %8b -> C1 = %8b -> C2 = %8b", b, ~b, r2);

r3 = ~c + 1;
$display("c = %6b -> C1 = %6b -> C2 = %6b", c, ~c, r3);

r4 = ~d + 1;
$display("d = %7b -> C1 = %7b -> C2 = %7b", d, ~d, r4);

r5 = ~e + 1;
$display("e = %8b -> C1 = %8b -> C2 = %8b", e, ~e, r5);

end

endmodule