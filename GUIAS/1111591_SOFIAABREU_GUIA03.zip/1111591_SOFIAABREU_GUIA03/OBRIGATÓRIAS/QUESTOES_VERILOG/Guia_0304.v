/*
 Guia_0304.v
 1111591 - Sofia
*/

module Guia_0304;

reg signed [7:0] a = 8'b00011011;
reg signed [7:0] b = 8'b00001101;
reg signed [15:0] c = 16'b0000000010110010;
reg signed [15:0] d = 16'b0000000011010111;
reg signed [15:0] e = 16'b0000101010000101;

reg signed [15:0] r;

initial
begin : main

$display("Guia_0304 - Testes");

$display("a = %8b = %d", a, a);
$display("b = %8b = %d", b, b);

r = a - b;
$display("a-b = %8b - %8b = %8b = %d", a, b, r, r);

$display("c = %16b = %d", c, c);
$display("d = %16b = %d", d, d);

r = c - d;
$display("c-d = %16b - %16b = %16b = %d", c, d, r, r);

$display("e = %16b = %d", e, e);

r = e - d;
$display("e-d = %16b - %16b = %16b = %d", e, d, r, r);

end

endmodule