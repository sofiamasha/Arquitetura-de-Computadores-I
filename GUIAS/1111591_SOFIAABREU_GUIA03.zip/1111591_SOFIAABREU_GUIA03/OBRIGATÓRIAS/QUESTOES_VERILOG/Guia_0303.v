/*
 Guia_0303.v
 1111591 - Sofia
*/

module Guia_0303;

reg signed [4:0] a = 5'b10111;
reg signed [5:0] b = 6'b110101;
reg signed [5:0] c = 6'b100100;
reg signed [6:0] d = 7'b1011011;
reg signed [6:0] e = 7'b1111101;

reg signed [7:0] r;

initial
begin : main

$display("Guia_0303 - Testes");

r = ~(a-1);
$display("a = %5b -> positivo = %5b = %d", a, r, r);

r = ~(b-1);
$display("b = %6b -> positivo = %6b = %d", b, r, r);

r = ~(c-1);
$display("c = %6b -> positivo = %6b = %d", c, r, r);

r = ~(d-1);
$display("d = %7b -> positivo = %7b = %d", d, r, r);

r = ~(e-1);
$display("e = %7b -> positivo = %7b = %d", e, r, r);

end

endmodule