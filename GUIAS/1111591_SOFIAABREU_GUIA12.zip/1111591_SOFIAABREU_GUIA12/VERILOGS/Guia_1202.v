module Guia_1202(
    input clk,
    input clr,
    input rw,
    input addr,
    input [7:0] data_in,
    output reg [7:0] data_out
);

reg [3:0] ram_low;
reg [3:0] ram_high;

always @(posedge clk or posedge clr) begin
    if (clr) begin
        ram_low <= 4'b0000;
        ram_high <= 4'b0000;
    end else if (rw && addr) begin
        ram_low <= data_in[3:0];
        ram_high <= data_in[7:4];
    end
end

always @(negedge clk) begin
    if (addr)
        data_out <= {ram_high, ram_low};
    else
        data_out <= 8'b00000000;
end

endmodule