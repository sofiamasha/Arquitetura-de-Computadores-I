module Guia_1206(
    input clk,
    input clr,
    input rw,
    input [1:0] addr,
    input [15:0] data_in,
    output reg [15:0] data_out
);

reg [7:0] ram_low [0:3];
reg [7:0] ram_high [0:3];

integer i;

always @(posedge clk or posedge clr) begin
    if (clr) begin
        for (i = 0; i < 4; i = i + 1) begin
            ram_low[i] <= 8'b0;
            ram_high[i] <= 8'b0;
        end
    end else if (rw) begin
        ram_low[addr]  <= data_in[7:0];
        ram_high[addr] <= data_in[15:8];
    end
end

always @(negedge clk) begin
    data_out <= {ram_high[addr], ram_low[addr]};
end

endmodule