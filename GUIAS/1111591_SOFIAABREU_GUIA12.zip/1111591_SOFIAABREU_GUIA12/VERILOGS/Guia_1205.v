module Guia_1205(
    input clk,
    input clr,
    input rw,
    input [2:0] addr,
    input [7:0] data_in,
    output reg [7:0] data_out
);

reg [7:0] mem0 [0:3];
reg [7:0] mem1 [0:3];

always @(posedge clk or posedge clr) begin
    if (clr) begin
        mem0[0] <= 0; mem0[1] <= 0; mem0[2] <= 0; mem0[3] <= 0;
        mem1[0] <= 0; mem1[1] <= 0; mem1[2] <= 0; mem1[3] <= 0;
    end else if (rw) begin
        if (addr < 4)
            mem0[addr] <= data_in;
        else
            mem1[addr-4] <= data_in;
    end
end

always @(negedge clk) begin
    if (addr < 4)
        data_out <= mem0[addr];
    else
        data_out <= mem1[addr-4];
end

endmodule