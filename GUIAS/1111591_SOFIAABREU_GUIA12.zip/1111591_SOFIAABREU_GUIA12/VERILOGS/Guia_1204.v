module Guia_1204(
    input clk,
    input clr,
    input rw,
    input [1:0] addr,
    input [7:0] data_in,
    output reg [7:0] data_out
);

reg [3:0] ram [0:3][1:0];

integer i;

always @(posedge clk or posedge clr) begin
    if (clr) begin
        for (i = 0; i < 4; i = i + 1) begin
            ram[i][0] <= 4'b0000;
            ram[i][1] <= 4'b0000;
        end
    end else if (rw) begin
        ram[addr][0] <= data_in[3:0];
        ram[addr][1] <= data_in[7:4];
    end
end

always @(negedge clk) begin
    data_out <= {ram[addr][1], ram[addr][0]};
end

endmodule