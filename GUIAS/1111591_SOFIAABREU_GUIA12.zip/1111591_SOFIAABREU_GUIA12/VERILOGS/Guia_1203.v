module Guia_1203(
    input clk,
    input clr,
    input rw,
    input addr,
    input [7:0] data_in,
    output reg [7:0] data_out
);

reg [3:0] mem0_low;
reg [3:0] mem0_high;
reg [3:0] mem1_low;
reg [3:0] mem1_high;

always @(posedge clk or posedge clr) begin
    if (clr) begin
        mem0_low <= 4'b0000;
        mem0_high <= 4'b0000;
        mem1_low <= 4'b0000;
        mem1_high <= 4'b0000;
    end else if (rw) begin
        if (addr == 0) begin
            mem0_low <= data_in[3:0];
            mem0_high <= data_in[7:4];
        end else begin
            mem1_low <= data_in[3:0];
            mem1_high <= data_in[7:4];
        end
    end
end

always @(negedge clk) begin
    if (addr == 0)
        data_out <= {mem0_high, mem0_low};
    else
        data_out <= {mem1_high, mem1_low};
end

endmodule