module Guia_1201(
    input clk,
    input clr,
    input rw,
    input addr,
    input [3:0] data_in,
    output reg [3:0] data_out
);

reg q0, q1, q2, q3;

always @(posedge clk or posedge clr) begin
    if (clr) begin
        q0 <= 0;
        q1 <= 0;
        q2 <= 0;
        q3 <= 0;
    end else if (rw && addr) begin
        q0 <= data_in[0];
        q1 <= data_in[1];
        q2 <= data_in[2];
        q3 <= data_in[3];
    end
end

always @(negedge clk) begin
    if (addr)
        data_out <= {q3, q2, q1, q0};
    else
        data_out <= 4'b0000;
end

endmodule