module tb;

reg clk;
reg clr;
reg rw;
reg [2:0] addr;
reg [15:0] data_in;

wire [15:0] data_out;

Guia_1205 uut(
    .clk(clk),
    .clr(clr),
    .rw(rw),
    .addr(addr),
    .data_in(data_in),
    .data_out(data_out)
);

always #5 clk = ~clk;

initial begin
    clk = 0;
    clr = 1;
    rw = 0;
    addr = 0;
    data_in = 0;

    #10 clr = 0;

    rw = 1;
    addr = 3'b101;
    data_in = 16'hAAAA;

    #10;

    rw = 0;
    addr = 3'b101;

    #10;

    rw = 1;
    addr = 3'b010;
    data_in = 16'h1234;

    #10;

    rw = 0;
    addr = 3'b010;

    #20;

    $finish;
end

initial begin
    $monitor("t=%0t addr=%b data_in=%h data_out=%h rw=%b", $time, addr, data_in, data_out, rw);
end

endmodule