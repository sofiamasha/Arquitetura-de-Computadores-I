module Guia_1207(
    input clk,
    input clr,
    input rw,
    input [2:0] addr,
    input [15:0] data_in,
    output reg [15:0] data_out
);

reg [3:0] mem [0:7][3:0];

integer i;

always @(posedge clk or posedge clr) begin
    if (clr) begin
        for (i = 0; i < 8; i = i + 1) begin
            mem[i][0] <= 0;
            mem[i][1] <= 0;
            mem[i][2] <= 0;
            mem[i][3] <= 0;
        end
    end else if (rw) begin
        mem[addr][0] <= data_in[3:0];
        mem[addr][1] <= data_in[7:4];
        mem[addr][2] <= data_in[11:8];
        mem[addr][3] <= data_in[15:12];
    end
end

always @(negedge clk) begin
    data_out <= {
        mem[addr][3],
        mem[addr][2],
        mem[addr][1],
        mem[addr][0]
    };
end

endmodule