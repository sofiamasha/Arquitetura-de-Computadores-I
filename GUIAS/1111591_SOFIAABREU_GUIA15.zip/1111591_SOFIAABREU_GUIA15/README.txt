README.txt

Aluno: Sofia Abreu
Matrícula: 1111591

Guia 15 - Introdução à Linguagem de Máquina (Assembly 8085)

Descrição Geral

Os programas foram desenvolvidos para o processador Intel 8085 seguindo o modelo apresentado em sala de aula e no Guia_1500.

Em todas as questões foram utilizados os registradores e instruções básicas do processador, como MOV, ADD, SUB, INX, STA, HLT e instruções auxiliares quando necessárias.

Questão 01 (Guia_1501)

Objetivo:
Calcular a expressão:

dado04 = dado01 - dado02 - dado03 - dado04

Estratégia:
O primeiro valor foi carregado para o acumulador e os demais foram subtraídos sequencialmente. O resultado final foi armazenado em dado04.

--------------------------------------------------

Questão 02 (Guia_1502)

Objetivo:
Calcular:

dado05 = dado01 - dado02 + dado03 + dado04

utilizando dados de 16 bits.

Estratégia:
Os dados foram tratados em dois bytes (parte baixa e parte alta). Foi utilizada a técnica de complemento de dois para realizar a subtração e posteriormente efetuadas as somas necessárias.

--------------------------------------------------

Questão 03 (Guia_1503)

Objetivo:
Calcular:

dado05 = dado01 + dado02 + dado03 - dado04

utilizando valores codificados em BCD.

Estratégia:
Após cada operação aritmética foi utilizada a instrução DAA (Decimal Adjust Accumulator) para garantir a correção do resultado em formato BCD.

--------------------------------------------------

Questão 04 (Guia_1504)

Objetivo:
Calcular:

dado03 = 4*dado01 - 3*dado02

Estratégia:
As multiplicações foram realizadas por somas sucessivas.
O valor 4*dado01 foi obtido dobrando o acumulador duas vezes.
O valor 3*dado02 foi obtido pela soma de dado02 com seu dobro.

--------------------------------------------------

Questão 05 (Guia_1505)

Objetivo:
Calcular:

dado03 = dado01*2 - dado02/2

Estratégia:
A multiplicação por 2 foi realizada através de uma soma do acumulador com ele mesmo.
A divisão por 2 foi implementada por subtrações sucessivas, evitando o uso de rotações conforme sugerido no enunciado.

--------------------------------------------------

Questão 06 (Guia_1506)

Objetivo:
Calcular:

dado03 = 2*(dado01 + 4*dado02)

Estratégia:
Primeiramente foi calculado 4*dado02 por duplicações sucessivas.
Em seguida foi realizada a soma com dado01.
Por fim o resultado foi multiplicado por 2.

--------------------------------------------------

Questão 07 (Guia_1507)

Objetivo:
Calcular:

dado03 = dado01 % 4 + dado02 / 2

Estratégia:
O operador módulo (%) foi obtido por subtrações sucessivas de 4 até restar um valor menor que 4.
A divisão por 2 foi realizada por subtrações sucessivas de 2.
Ao final os dois resultados foram somados.

--------------------------------------------------

Observações

Todos os programas foram implementados utilizando instruções compatíveis com o processador Intel 8085 e testados em simulador.

Foram priorizadas soluções simples e didáticas, seguindo as orientações fornecidas no enunciado das atividades.