module Guia_1103;

reg clk;
reg reset;
reg x;

wire y;

moore_1011 detector (
    y,
    x,
    clk,
    reset
);

always
    #5 clk = ~clk;

initial
begin

    $display("Time X Y");

    clk = 1;
    reset = 0;
    x = 0;

    #5 reset = 1;

    #10 x = 1;
    #10 x = 0;
    #10 x = 0;
    #10 x = 1;
    #10 x = 0;
    #10 x = 1;
    #10 x = 0;
    #10 x = 1;
    #10 x = 1;
    #10 x = 0;
    #10 x = 1;
    #10 x = 1;
    #10 x = 0;
    #10 x = 0;
    #10 x = 1;

    #20 $finish;

end

initial
begin
    $monitor("%4d   %b   %b",
             $time, x, y);
end

endmodule

module moore_1011 ( y, x, clk, reset );

output reg y;

input x;
input clk;
input reset;

parameter
    start   = 3'b000,
    id1     = 3'b001,
    id10    = 3'b010,
    id101   = 3'b011,
    id1011  = 3'b100;

reg [2:0] E1;
reg [2:0] E2;

always @( x or E1 )
begin

    case ( E1 )

        start:
            if ( x )
                E2 = id1;
            else
                E2 = start;

        id1:
            if ( x )
                E2 = id1;
            else
                E2 = id10;

        id10:
            if ( x )
                E2 = id101;
            else
                E2 = start;

        id101:
            if ( x )
                E2 = id1011;
            else
                E2 = id10;

        id1011:
            if ( x )
                E2 = id1;
            else
                E2 = id10;

        default:
            E2 = start;

    endcase

end

always @( E1 )
begin

    case ( E1 )

        id1011:
            y = 1'b1;

        default:
            y = 1'b0;

    endcase

end

always @( posedge clk or negedge reset )
begin

    if ( reset == 0 )
        E1 <= start;
    else
        E1 <= E2;

end

endmodule