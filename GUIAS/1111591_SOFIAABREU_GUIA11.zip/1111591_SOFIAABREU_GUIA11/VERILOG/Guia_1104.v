module Guia_1104;

reg clk;
reg reset;
reg x;

wire y;

fsm_111 detector (
    y,
    x,
    clk,
    reset
);

always
    #5 clk = ~clk;

initial
begin

    $display("Time X Y");

    clk = 1;
    reset = 0;
    x = 0;

    #5 reset = 1;

    #10 x = 1;
    #10 x = 0;
    #10 x = 1;
    #10 x = 1;
    #10 x = 1;
    #10 x = 0;
    #10 x = 1;
    #10 x = 1;
    #10 x = 1;

    #20 $finish;

end

initial
begin
    $monitor("%4d   %b   %b",
             $time, x, y);
end

endmodule

module fsm_111 ( y, x, clk, reset );

output reg y;

input x;
input clk;
input reset;

parameter
    start  = 2'b00,
    id1    = 2'b01,
    id11   = 2'b10,
    id111  = 2'b11;

reg [1:0] E1;
reg [1:0] E2;

always @( x or E1 )
begin

    case ( E1 )

        start:
            if ( x )
                E2 = id1;
            else
                E2 = start;

        id1:
            if ( x )
                E2 = id11;
            else
                E2 = start;

        id11:
            if ( x )
                E2 = id111;
            else
                E2 = start;

        id111:
            if ( x )
                E2 = id111;
            else
                E2 = start;

        default:
            E2 = start;

    endcase

end

always @( E1 )
begin

    case ( E1 )

        id111:
            y = 1'b1;

        default:
            y = 1'b0;

    endcase

end

always @( posedge clk or negedge reset )
begin

    if ( reset == 0 )
        E1 <= start;
    else
        E1 <= E2;

end

endmodule