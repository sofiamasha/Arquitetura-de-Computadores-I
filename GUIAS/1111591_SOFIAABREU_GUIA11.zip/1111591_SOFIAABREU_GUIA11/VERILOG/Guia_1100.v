`include "mealy_1101.v"
`include "moore_1101.v"

module Guia_1100;

reg clk;
reg reset;
reg x;

wire m1;
wire m2;

mealy_1101 mealy1 ( m1, x, clk, reset );
moore_1101 moore1 ( m2, x, clk, reset );

always
    #5 clk = ~clk;

initial
begin

    $display("Time X Mealy Moore");

    clk = 1;
    reset = 0;
    x = 0;

    #5 reset = 1;

    #10 x = 1;
    #10 x = 1;
    #10 x = 0;
    #10 x = 1;

    #10 x = 0;
    #10 x = 1;
    #10 x = 1;
    #10 x = 0;
    #10 x = 1;

    #10 $finish;

end

initial
begin
    $monitor("%4d   %b    %b      %b",
             $time, x, m1, m2);
end

endmodule