module Guia_1102;

reg clk;
reg reset;
reg x;

wire y;

mealy_1001 detector (
    y,
    x,
    clk,
    reset
);

always
    #5 clk = ~clk;

initial
begin

    $display("Time X Y");

    clk = 1;
    reset = 0;
    x = 0;

    #5 reset = 1;

    #10 x = 1;
    #10 x = 0;
    #10 x = 0;
    #10 x = 1;

    #10 x = 0;
    #10 x = 1;
    #10 x = 0;
    #10 x = 1;
    #10 x = 0;
    #10 x = 1;

    #20 $finish;

end

initial
begin
    $monitor("%4d   %b   %b",
             $time, x, y);
end

endmodule

module mealy_1001 ( y, x, clk, reset );

output reg y;

input x;
input clk;
input reset;

parameter
    start  = 2'b00,
    id1    = 2'b01,
    id10   = 2'b10,
    id100  = 2'b11;

reg [1:0] E1;
reg [1:0] E2;

always @( x or E1 )
begin

    y = 1'b0;

    case ( E1 )

        start:
            if ( x )
                E2 = id1;
            else
                E2 = start;

        id1:
            if ( x )
                E2 = id1;
            else
                E2 = id10;

        id10:
            if ( x )
                E2 = id1;
            else
                E2 = id100;

        id100:
            if ( x )
            begin
                E2 = start;
                y = 1'b1;
            end
            else
                E2 = start;

        default:
            E2 = start;

    endcase

end

always @( posedge clk or negedge reset )
begin

    if ( reset == 0 )
        E1 <= start;
    else
        E1 <= E2;

end

endmodule