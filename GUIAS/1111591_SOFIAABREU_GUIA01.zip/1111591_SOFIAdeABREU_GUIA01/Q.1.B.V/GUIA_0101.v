/*
 Guia_0101.v
 1111591 - Sofia de Abreu
*/

module Guia_0101;


 integer a = 27;
 integer b = 56;
 integer c = 753;
 integer d = 321;
 integer e = 366;

 reg [15:0] bin = 0; 


 initial
 begin : main

  $display("Guia_0101 - Conversoes Decimal -> Binario");

  bin = a;
  $display("27  = %b", bin);

  bin = b;
  $display("56  = %b", bin);

  bin = c;
  $display("753 = %b", bin);

  bin = d;
  $display("321 = %b", bin);

  bin = e;
  $display("366 = %b", bin);

 end

endmodule