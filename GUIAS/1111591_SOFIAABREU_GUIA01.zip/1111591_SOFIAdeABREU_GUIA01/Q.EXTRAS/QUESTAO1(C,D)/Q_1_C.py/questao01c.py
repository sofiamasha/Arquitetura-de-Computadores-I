# ============================================================
# Disciplina: ARQ
# Aluno: SOFIA
#
# Questão 01c:
# Desenvolver uma função dec2bin(x) que receba um número
# decimal (base 10) e retorne sua representação em binário
# (base 2), utilizando linguagem de programação.
# ============================================================


def dec2bin(x):

    if x == 0:
        return "0"

    resultado = ""

    while x > 0:
        resto = x % 2
        resultado = str(resto) + resultado
        x = x // 2

    return resultado


# Lista de valores para teste
valores = [27, 56, 753, 321, 366]

print("Conversão de Decimal para Binário:\n")

for numero in valores:
    print(f"{numero} -> {dec2bin(numero)}")