/*
  Guia_0102.v
  SOFIA
  Questao 02b - Conversao de Binario para Decimal
*/

module Guia_0102;

 integer x;      // decimal
 reg [7:0] b;    // binario (8 bits)

 initial
 begin
  $display("Guia_0102 - Conversoes Binario -> Decimal\n");

  // a) 10010(2)
  b = 8'b00010010; 
  x = b;
  $display("10010(2) = %d(10)", x);

  // b) 10101(2)
  b = 8'b00010101; 
  x = b;
  $display("10101(2) = %d(10)", x);

  // c) 10110(2)
  b = 8'b00010110; 
  x = b;
  $display("10110(2) = %d(10)", x);

  // d) 101011(2)
  b = 8'b00101011; 
  x = b;
  $display("101011(2) = %d(10)", x);

  // e) 111011(2)
  b = 8'b00111011; 
  x = b;
  $display("111011(2) = %d(10)", x);

 end

endmodule