# ============================================================
# Disciplina: arq
# Aluno: SOFIA
#
# Questao 02c:
# Desenvolver uma função bin2dec(x) que receba um número
# binário e retorne sua representação decimal.
# ============================================================


def bin2dec(x):

    decimal = 0
    potencia = 0

    for digito in reversed(x):
        decimal += int(digito) * (2 ** potencia)
        potencia += 1

    return decimal


# Testes
valores = ["10010", "10101", "10110", "101011", "111011"]

print("Conversao de Binario para Decimal:\n")

for v in valores:
    print(f"{v}(2) = {bin2dec(v)}(10)")