/*
 Guia_0103.v
 SOFIA
 Conversoes Decimal para Bases 2, 8 e 16
*/

module Guia_0103;

 integer x; 
 reg [15:0] b;

 initial
 begin
  $display("Guia_0103 - Tests\n");

  x = 49;
  b = x;
  $display("49(10)  = %o(8)  = %x(16)", b, b);

  x = 61;
  b = x;
  $display("61(10)  = %o(8)  = %x(16)", b, b);

  x = 77;
  b = x;
  $display("77(10)  = %o(8)  = %x(16)", b, b);

  x = 135;
  b = x;
  $display("135(10) = %o(8)  = %x(16)", b, b);

  x = 763;
  b = x;
  $display("763(10) = %o(8)  = %x(16)", b, b);

 end

endmodule