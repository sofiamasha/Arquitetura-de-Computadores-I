# ============================================================
# Disciplina: ARQ
# Aluno: SOFIA
#
# Questao 03c:
# Desenvolver função para converter numero decimal
# para a base indicada (4, 8 ou 16).
# ============================================================

def dec2base(x, base):

    if x == 0:
        return "0"

    digitos = "0123456789ABCDEF"
    resultado = ""

    while x > 0:
        resto = x % base
        resultado = digitos[resto] + resultado
        x = x // base

    return resultado


print("49(10)  =", dec2base(49, 4),  "(4)")
print("61(10)  =", dec2base(61, 8),  "(8)")
print("77(10)  =", dec2base(77, 16), "(16)")
print("135(10) =", dec2base(135, 16), "(16)")
print("763(10) =", dec2base(763, 16), "(16)")