/*
 Guia_0104.v
 SOFIA
 Conversoes por Agrupamento
*/

module Guia_0104;

 reg [7:0] b;

 initial
 begin
  $display("Guia_0104 - Agrupamentos\n");

  b = 8'b00010101; // 10101
  $display("10101(2)  -> base4:  %b %b", b[5:4], b[3:2]);

  b = 8'b00011000; // 11000
  $display("11000(2)  -> base8:  %o", b);

  b = 8'b00100101; // 100101
  $display("100101(2) -> base16: %x", b);

  b = 8'b00101101; // 101101
  $display("101101(2) -> base8:  %o", b);

  b = 8'b00110101; // 110101
  $display("110101(2) -> base4 (manual agrupamento)");

 end

endmodule