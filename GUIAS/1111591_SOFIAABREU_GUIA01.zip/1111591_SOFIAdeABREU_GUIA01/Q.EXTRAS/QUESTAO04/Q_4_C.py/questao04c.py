# ============================================================
# Disciplina: ARQ
# Aluno: SOFIA
#
# Questao 04c:
# Conversoes utilizando funcao bin2dec(x)
# ============================================================

def bin2dec(x):
    return int(x, 2)

def dec2bin(x):
    return bin(x)[2:]

def dec2base4(x):
    if x == 0:
        return "0"
    r = ""
    while x > 0:
        r = str(x % 4) + r
        x //= 4
    return r

def dec2base8(x):
    return oct(x)[2:]

def dec2base16(x):
    return hex(x)[2:].upper()

binario = "10100011"

decimal = bin2dec(binario)

print("Decimal:", decimal)
print("Base 2:", dec2bin(decimal))
print("Base 4:", dec2base4(decimal))
print("Base 8:", dec2base8(decimal))
print("Base 16:", dec2base16(decimal))