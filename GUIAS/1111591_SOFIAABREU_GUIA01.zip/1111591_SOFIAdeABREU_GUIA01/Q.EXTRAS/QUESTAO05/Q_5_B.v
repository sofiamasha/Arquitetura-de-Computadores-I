/*
 Guia_0105.v
 1111591 - SOFIA
*/

module Guia_0105;


integer x = 13;            
reg [7:0] b;               
reg [0:2][7:0] s = "PUC";  


initial
begin : main

    $display("Guia_0105 - Tests");


    $display("x = %d", x);
    b = x;
    $display("b = %8b", b);
    $display("b = [%4b] [%4b] = %h %h", b[7:4], b[3:0], b[7:4], b[3:0]);

    $display("s = %s", s);

    s[0] = "-";
    s[1] = 8'b01001101;  // 'M'
    s[2] = 71;           // 'G'

    $display("s = %s", s);

 

    $display("\n05b - Conversoes ASCII");

    $display("\"PUC-Minas\" em hexadecimal:");
    $display("%h %h %h %h %h %h %h %h %h",
        "P","U","C","-","M","i","n","a","s");

    $display("\"2026-01\" em hexadecimal:");
    $display("%h %h %h %h %h %h %h",
        "2","0","2","6","-","0","1");

    $display("\"Minas Gerais\" em binario:");
    $display("%b %b %b %b %b %b %b %b %b %b %b %b",
        "M","i","n","a","s"," ","G","e","r","a","i","s");

    $display("\nOctal 115 101 116 110 101 -> ASCII:");
    $display("%s%s%s%s%s", 8'o115,8'o101,8'o116,8'o110,8'o101);

    $display("Hex 54 61 72 64 65 -> ASCII:");
    $display("%s%s%s%s%s", 8'h54,8'h61,8'h72,8'h64,8'h65);

end

endmodule