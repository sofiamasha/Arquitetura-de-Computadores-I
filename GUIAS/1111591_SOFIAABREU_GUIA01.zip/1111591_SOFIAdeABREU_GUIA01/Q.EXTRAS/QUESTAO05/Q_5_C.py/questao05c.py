# ============================================================
# Disciplina: ARQ
# Aluno: SOFIA
#
# Questao 5c
# ============================================================
def ASCII2hex(texto):
    resultado = ""
    for c in texto:
        resultado += format(ord(c), "02X") + " "
    return resultado.strip()

def hex2ASCII(hex_string):
    resultado = ""
    partes = hex_string.split()
    for h in partes:
        resultado += chr(int(h, 16))
    return resultado


# Testes
print(ASCII2hex("PUC-Minas"))
print(ASCII2hex("2026-01"))
print(hex2ASCII("50 55 43 2D 4D 69 6E 61 73"))
print(hex2ASCII("54 61 72 64 65"))