JMP MAIN

F_IMUL:
        MVI A,00

LOOPM:
        MOV D,C
        MOV E,D
        MOV D,A

        MOV A,E
        ORA A
        JZ FIMM

        MOV A,D
        ADD B

        DCR C

        JMP LOOPM

FIMM:
        RET

F_FAT:
        MVI D,01
        MOV E,B

LOOPF:
        MOV A,E
        ORA A
        JZ FIMF

        MOV B,D
        MOV C,E

        CALL F_IMUL

        MOV D,A

        DCR E

        JMP LOOPF

FIMF:
        MOV A,D
        RET

MAIN:
        LXI H,0050

        MOV B,M

        CALL F_FAT

        STA 0052

        HLT

END