JMP MAIN

F_SQR:
        MVI A,00
        MVI D,01

LOOP:
        MOV E,B
        MOV A,E
        ORA A
        JZ FIM

        MOV A,C
        ADD D
        MOV C,A

        MOV A,D
        ADI 02
        MOV D,A

        DCR B

        JMP LOOP

FIM:
        MOV A,C
        RET

MAIN:
        LXI H,0050

        MOV B,M

        MVI C,00

        CALL F_SQR

        STA 0052

        HLT

END